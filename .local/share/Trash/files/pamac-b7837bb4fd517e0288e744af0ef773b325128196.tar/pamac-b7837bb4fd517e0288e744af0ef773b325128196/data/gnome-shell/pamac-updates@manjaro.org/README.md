# pamac-updates
GNOME Shell Updates indicator for Pamac

## Features
- Optional update count display on panel
- Optional notification on new updates

## Credits
This is only a rebranded and customized extension, original extension can be found here
https://github.com/RaphaelRochet/arch-update

Any credit at the original author Raphaël Rochet

Contributor [Matti Hyttinen](https://github.com/Chrysostomus)
